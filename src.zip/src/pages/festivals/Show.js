import React from 'react'

const Show = () => {
  return (
    <h2>Festival</h2>
  )
}

export default Show